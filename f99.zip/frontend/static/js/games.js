import { getState } from "./state.js";

const STORAGE_PREFIX = "astrohealth-focus-v1";
const TRIALS = 12;

function storageKey(astronaut) {
    return `${STORAGE_PREFIX}:${astronaut || "AH-001"}`;
}

function readLocal(astronaut) {
    try {
        return JSON.parse(localStorage.getItem(storageKey(astronaut))) || {
            sessions: [], points: 0, streak: 0, lastPlayedDay: null
        };
    } catch {
        return { sessions: [], points: 0, streak: 0, lastPlayedDay: null };
    }
}

function saveLocal(astronaut, data) {
    try { localStorage.setItem(storageKey(astronaut), JSON.stringify(data)); }
    catch (error) { console.warn("Focus game progress could not be saved:", error); }
}

function dayKey(date = new Date()) {
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

function median(values) {
    const sorted = [...values].sort((a, b) => a - b);
    const middle = Math.floor(sorted.length / 2);
    return sorted.length % 2 ? sorted[middle] : Math.round((sorted[middle - 1] + sorted[middle]) / 2);
}

function scoreReaction(times, falseStarts) {
    if (!times.length) return 0;
    const med = median(times);
    const lapses = times.filter(value => value > 500).length;
    return Math.max(0, Math.min(100, Math.round(100 - Math.max(0, med - 200) * 0.12 - lapses * 5 - falseStarts * 3)));
}

function recordSession(astronaut, session) {
    const data = readLocal(astronaut);
    const today = dayKey();
    const previousBest = Math.max(0, ...data.sessions.filter(item => item.game === session.game).map(item => item.score));
    const bonus = session.score > previousBest ? 15 : 0;
    const earned = 25 + bonus;

    if (data.lastPlayedDay !== today) {
        const yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);
        data.streak = data.lastPlayedDay === dayKey(yesterday) ? data.streak + 1 : 1;
        data.lastPlayedDay = today;
    }

    data.points += earned;
    data.sessions.unshift({ ...session, astronaut, timestamp: new Date().toISOString(), points: earned });
    data.sessions = data.sessions.slice(0, 60);
    saveLocal(astronaut, data);
    return { data, earned, bonus, previousBest };
}

function getTodayScore(data) {
    const today = dayKey();
    const scores = data.sessions.filter(item => item.timestamp?.slice(0, 10) === today).map(item => item.score);
    return scores.length ? Math.round(scores.reduce((sum, value) => sum + value, 0) / scores.length) : null;
}

function drawHistory(canvas, sessions) {
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    const width = canvas.clientWidth || 320;
    const height = canvas.clientHeight || 86;
    const ratio = window.devicePixelRatio || 1;
    canvas.width = width * ratio;
    canvas.height = height * ratio;
    ctx.scale(ratio, ratio);
    ctx.clearRect(0, 0, width, height);
    ctx.strokeStyle = "rgba(135,170,195,.13)";
    ctx.lineWidth = 1;
    for (let y = 15; y < height; y += 22) {
        ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(width, y); ctx.stroke();
    }
    const points = sessions.slice(0, 10).reverse();
    if (!points.length) {
        ctx.fillStyle = "#8296a9"; ctx.font = "11px monospace";
        ctx.fillText("Complete a game to start your trend", 8, height / 2 + 4);
        return;
    }
    const values = points.map(item => item.score);
    const xStep = points.length > 1 ? (width - 18) / (points.length - 1) : 0;
    const y = value => height - 10 - (value / 100) * (height - 22);
    ctx.strokeStyle = "rgba(66,201,232,.22)";
    ctx.setLineDash([4, 4]); ctx.beginPath(); ctx.moveTo(0, y(70)); ctx.lineTo(width, y(70)); ctx.stroke(); ctx.setLineDash([]);
    ctx.beginPath();
    points.forEach((item, index) => {
        const px = 9 + index * xStep;
        if (index === 0) ctx.moveTo(px, y(item.score)); else ctx.lineTo(px, y(item.score));
    });
    ctx.strokeStyle = "#42c9e8"; ctx.lineWidth = 2; ctx.stroke();
    points.forEach((item, index) => {
        ctx.beginPath(); ctx.arc(9 + index * xStep, y(item.score), 3, 0, Math.PI * 2);
        ctx.fillStyle = "#45dda0"; ctx.fill();
    });
}

export function renderGamesPage(main, showToast = () => {}) {
    const astronaut = getState().astronaut || "AH-001";
    let local = readLocal(astronaut);
    let cleanup = null;

    const todayScore = getTodayScore(local);
    const bestFor = game => Math.max(0, ...local.sessions.filter(item => item.game === game).map(item => item.score));
    const lastFor = game => local.sessions.find(item => item.game === game);
    const dateLabel = item => item ? new Date(item.timestamp).toLocaleDateString() : "Not played yet";

    main.innerHTML = `
      <section class="page-header focus-page-header">
        <div><p class="page-eyebrow">MISSION MODULE / COGNITIVE READINESS</p>
          <h2 class="page-title">Focus <span>Games</span></h2>
          <p class="page-description">Short cognitive check-ins for mission alertness and readiness.</p>
        </div><span class="badge badge-cyan">SIMULATED DATA</span>
      </section>
      <div class="focus-disclaimer" role="note"><strong>ⓘ Experimental cognitive check-in.</strong> Not a medical test or diagnosis. NASA uses similar reaction-time vigilance tests to track alertness in crews.</div>
      <section class="focus-summary-grid" aria-label="Focus summary">
        <article class="panel focus-score-card"><div class="focus-label">TODAY'S FOCUS SCORE</div>
          <div class="focus-score-value">${todayScore === null ? "—" : todayScore}<small>/100</small></div>
          <p>${todayScore === null ? "Play one game to create today's score." : "Average of games completed today."}</p>
        </article>
        <article class="panel focus-stat-card"><div class="focus-label">MISSION STREAK</div><strong>${local.streak} <small>days</small></strong><p>Consecutive days with a check-in</p></article>
        <article class="panel focus-stat-card"><div class="focus-label">FOCUS POINTS</div><strong>${local.points}</strong><p>Earn 25 points per completed game</p></article>
      </section>
      <section class="panel focus-how"><div class="panel-heading"><div><h3>How it works</h3><p>WHY FOCUS MATTERS ON LONG MISSIONS</p></div><span class="badge badge-green">SELF-CHECK</span></div>
        <p>Fatigue, isolation and disrupted sleep can affect attention and reaction time. These short activities help you notice changes in your own performance. Results are intended to be compared with <strong>your personal baseline</strong>, not with another crew member.</p>
      </section>
      <section class="focus-games-section"><div class="panel-heading"><div><h3>Choose a cognitive check-in</h3><p>THREE SHORT ACTIVITIES · KEYBOARD OR TOUCH</p></div><span class="badge badge-cyan">${astronaut}</span></div>
        <div class="focus-game-grid">
          <article class="panel focus-game-card"><div class="focus-game-icon" aria-hidden="true">◉</div><div class="focus-label">REACTION / VIGILANCE</div><h3>Reaction Pulse</h3><p>Measure how quickly you respond to a visual signal.</p><div class="focus-game-meta"><span>⏱ About 1 min</span><span>Best: ${bestFor("reaction") || "—"}</span></div><p class="focus-last-played">Last played: ${dateLabel(lastFor("reaction"))}</p><button class="btn btn-primary focus-play" data-game="reaction">Play Reaction Pulse <span aria-hidden="true">→</span></button></article>
          <article class="panel focus-game-card"><div class="focus-game-icon" aria-hidden="true">◈</div><div class="focus-label">SELECTIVE ATTENTION</div><h3>Color Clash</h3><p>Choose the ink color while ignoring the written word.</p><div class="focus-game-meta"><span>⏱ About 2 min</span><span>Best: ${bestFor("stroop") || "—"}</span></div><p class="focus-last-played">Last played: ${dateLabel(lastFor("stroop"))}</p><button class="btn focus-play focus-play-secondary" disabled aria-disabled="true">Available in Step 2</button></article>
          <article class="panel focus-game-card"><div class="focus-game-icon" aria-hidden="true">▦</div><div class="focus-label">WORKING MEMORY</div><h3>Memory Grid</h3><p>Remember and repeat a growing sequence of lights.</p><div class="focus-game-meta"><span>⏱ About 2 min</span><span>Best: ${bestFor("memory") || "—"}</span></div><p class="focus-last-played">Last played: ${dateLabel(lastFor("memory"))}</p><button class="btn focus-play focus-play-secondary" disabled aria-disabled="true">Available in Step 2</button></article>
        </div>
      </section>
      <section class="panel focus-history"><div class="panel-heading"><div><h3>Recent focus sessions</h3><p>YOUR RECENT SCORES · PERSONAL PROGRESS</p></div><span class="badge badge-cyan">LOCAL DEMO HISTORY</span></div><canvas class="focus-history-canvas" aria-label="Recent focus scores chart"></canvas><div class="focus-history-foot"><span>0</span><span>Personal session scores (0–100)</span><span>100</span></div></section>
      <div class="focus-game-stage" hidden></div>
      <p class="focus-footer-note">Experimental cognitive check-in. Not a medical test.</p>
    `;

    drawHistory(main.querySelector(".focus-history-canvas"), local.sessions);

    const stage = main.querySelector(".focus-game-stage");
    const onPlay = event => {
        const button = event.target.closest("[data-game='reaction']");
        if (button) startReaction();
    };
    main.addEventListener("click", onPlay);

    function startReaction() {
        if (cleanup) cleanup();
        stage.hidden = false;
        stage.innerHTML = `
          <section class="panel reaction-panel" aria-label="Reaction Pulse game">
            <div class="panel-heading"><div><h3>Reaction Pulse</h3><p>PSYCHOMOTOR VIGILANCE · 12 TRIALS</p></div><span class="badge badge-cyan" id="rp-progress">READY</span></div>
            <p class="reaction-instructions">Wait for the ring to turn cyan, then press <kbd>SPACE</kbd> or tap the ring as quickly as you can. Don't anticipate the signal.</p>
            <div class="reaction-ring-wrap"><button class="reaction-ring" type="button" id="rp-target" aria-label="Wait for the cyan signal, then press Space or activate this button"><span id="rp-target-text">READY</span></button></div>
            <div class="reaction-feedback" id="rp-feedback" aria-live="polite">12 trials · Random signal delay 2–8 seconds</div>
            <div class="reaction-controls"><button class="btn btn-primary" id="rp-start">Start</button><button class="btn" id="rp-pause" disabled>Pause</button><button class="btn" id="rp-exit">Exit</button></div>
            <div class="reaction-last" id="rp-last">Your reaction time will appear here.</div>
          </section>`;
        stage.scrollIntoView({ behavior: matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth", block: "start" });
        const finishToHub = () => {
            local = readLocal(astronaut);
            drawHistory(main.querySelector(".focus-history-canvas"), local.sessions);
            stage.hidden = true;
            stage.innerHTML = "";
            cleanup = null;
            renderGamesSummaryRefresh(main, local);
        };
        setupReaction(stage, astronaut, showToast, finishToHub, startReaction, fn => { cleanup = fn; });
    }

    return () => {
        main.removeEventListener("click", onPlay);
        if (cleanup) cleanup();
    };
}

function renderGamesSummaryRefresh(main, local) {
    const score = getTodayScore(local);
    const scoreValue = main.querySelector(".focus-score-value");
    const scoreText = main.querySelector(".focus-score-card p");
    const streak = main.querySelector(".focus-stat-card strong");
    const points = main.querySelectorAll(".focus-stat-card strong")[1];
    if (scoreValue) scoreValue.innerHTML = `${score ?? "—"}<small>/100</small>`;
    if (scoreText) scoreText.textContent = score === null ? "Play one game to create today's score." : "Average of games completed today.";
    if (streak) streak.innerHTML = `${local.streak} <small>days</small>`;
    if (points) points.textContent = local.points;
}

function setupReaction(stage, astronaut, showToast, onFinish, onRestart, setCleanup) {
    const target = stage.querySelector("#rp-target");
    const targetText = stage.querySelector("#rp-target-text");
    const progress = stage.querySelector("#rp-progress");
    const feedback = stage.querySelector("#rp-feedback");
    const last = stage.querySelector("#rp-last");
    const startButton = stage.querySelector("#rp-start");
    const pauseButton = stage.querySelector("#rp-pause");
    const exitButton = stage.querySelector("#rp-exit");

    let phase = "idle";
    let timer = null;
    let startAt = 0;
    let trial = 0;
    let falseStarts = 0;
    let times = [];
    let countdown = 3;
    let disposed = false;
    let pausedRemaining = 0;
    let signalDelay = 0;
    let signalDue = 0;
    let countdownTimer = null;

    const clearTimers = () => { clearTimeout(timer); clearInterval(countdownTimer); timer = null; countdownTimer = null; };

    function updateProgress() { progress.textContent = phase === "complete" ? "COMPLETE" : `TRIAL ${Math.min(trial + 1, TRIALS)} / ${TRIALS}`; }

    function showResults() {
        phase = "complete"; clearTimers(); dispose(); target.disabled = true; target.classList.remove("is-ready", "is-waiting");
        const med = median(times); const fastest = Math.min(...times); const slowest = Math.max(...times);
        const lapses = times.filter(value => value > 500).length; const score = scoreReaction(times, falseStarts);
        const saved = recordSession(astronaut, { game: "reaction", score, details: { medianMs: med, fastestMs: fastest, slowestMs: slowest, lapses, falseStarts, trials: times.length } });
        stage.querySelector(".reaction-panel").innerHTML = `
          <div class="panel-heading"><div><h3>Reaction Pulse · Results</h3><p>SESSION COMPLETE · ${times.length} VALID TRIALS</p></div><span class="badge badge-green">SAVED LOCALLY</span></div>
          <div class="reaction-result-score"><div class="reaction-score-ring" style="--score:${score}"><strong>${score}</strong><span>/100</span></div><div><div class="focus-label">REACTION SCORE</div><p>${score >= 80 ? "Strong session. Keep comparing with your own baseline." : score >= 60 ? "A mixed session. Consider a short break and repeat later." : "Consider rest and a later re-check; this is not a diagnosis."}</p></div></div>
          <div class="reaction-result-grid"><div><small>MEDIAN</small><strong>${med} ms</strong></div><div><small>FASTEST</small><strong>${fastest} ms</strong></div><div><small>SLOWEST</small><strong>${slowest} ms</strong></div><div><small>LAPSES (&gt;500 ms)</small><strong>${lapses}</strong></div><div><small>FALSE STARTS</small><strong>${falseStarts}</strong></div></div>
          <p class="focus-disclaimer">This experimental check-in is not a medical test or diagnosis. Interpret results against your personal baseline.</p>
          <div class="reaction-controls"><button class="btn btn-primary" id="rp-again">Play again</button><button class="btn" id="rp-done">Return to Games</button></div>`;
        showToast(`Reaction Pulse complete · +${saved.earned} focus points${saved.bonus ? " · personal best bonus +15" : ""}`, "success");
        stage.querySelector("#rp-again").addEventListener("click", () => {
            dispose();
            onRestart();
        });
        stage.querySelector("#rp-done").addEventListener("click", onFinish);
        updateProgress();
    }

    function scheduleSignal(delay = 2000 + Math.random() * 6000) {
        phase = "waiting"; target.disabled = false; target.classList.remove("is-ready"); target.classList.add("is-waiting");
        targetText.textContent = "WAIT"; feedback.textContent = "Stay ready. Wait for the cyan signal.";
        signalDelay = delay; signalDue = Date.now() + delay;
        timer = setTimeout(() => {
            if (disposed || phase !== "waiting") return;
            phase = "ready"; startAt = performance.now(); target.classList.remove("is-waiting"); target.classList.add("is-ready");
            targetText.textContent = "PRESS!"; feedback.textContent = "Signal active — respond now!";
        }, delay);
        updateProgress();
    }

    function handleResponse() {
        if (disposed || phase === "idle" || phase === "paused" || phase === "countdown" || phase === "complete") return;
        if (phase === "waiting") {
            falseStarts += 1; clearTimeout(timer); target.classList.remove("is-waiting"); target.classList.add("is-false");
            targetText.textContent = "EARLY"; feedback.textContent = `False start ${falseStarts}. Wait for the signal.`;
            last.textContent = "False start recorded — the same trial will repeat.";
            timer = setTimeout(() => { if (!disposed && phase !== "paused") scheduleSignal(); }, 850);
            return;
        }
        if (phase === "ready") {
            const elapsed = Math.round(performance.now() - startAt); times.push(elapsed); trial += 1;
            phase = "feedback"; clearTimeout(timer); target.classList.remove("is-ready"); targetText.textContent = `${elapsed} ms`;
            feedback.textContent = elapsed > 500 ? "Lapse recorded (>500 ms)." : "Response recorded.";
            last.textContent = `Trial ${trial}/${TRIALS}: ${elapsed} ms`;
            updateProgress();
            if (trial >= TRIALS) { timer = setTimeout(showResults, 700); }
            else { timer = setTimeout(() => scheduleSignal(), 900); }
        }
    }

    function beginCountdown() {
        clearTimers(); phase = "countdown"; countdown = 3; trial = 0; falseStarts = 0; times = [];
        target.disabled = true; target.classList.remove("is-ready", "is-waiting", "is-false"); targetText.textContent = String(countdown);
        feedback.textContent = "Get ready…"; startButton.disabled = true; pauseButton.disabled = false; pauseButton.textContent = "Pause";
        countdownTimer = setInterval(() => {
            countdown -= 1;
            if (countdown > 0) targetText.textContent = String(countdown);
            else { clearInterval(countdownTimer); countdownTimer = null; startButton.disabled = false; scheduleSignal(); }
        }, 700);
    }

    function pauseGame() {
        if (["idle", "complete", "paused"].includes(phase)) return;
        if (phase === "waiting") pausedRemaining = Math.max(250, signalDue - Date.now());
        clearTimers(); phase = "paused"; target.disabled = true; target.classList.remove("is-ready", "is-waiting"); targetText.textContent = "PAUSED";
        feedback.textContent = "Game paused. Press Resume when ready."; pauseButton.textContent = "Resume"; startButton.disabled = true;
    }

    function resumeGame() {
        if (phase !== "paused") return;
        startButton.disabled = false; pauseButton.textContent = "Pause";
        if (times.length === 0 && trial === 0) beginCountdown();
        else scheduleSignal(pausedRemaining || 1000);
    }

    function onKey(event) {
        if (event.code === "Space" && !event.repeat && !disposed) {
            event.preventDefault(); handleResponse();
        }
    }
    function onVisibility() { if (document.hidden) pauseGame(); }
    function onStart() { if (phase === "paused") resumeGame(); else if (phase === "idle") beginCountdown(); }
    function onPause() { if (phase === "paused") resumeGame(); else pauseGame(); }
    function onExit() { dispose(); onFinish(); }
    function dispose() {
        if (disposed) return; disposed = true; clearTimers();
        target.removeEventListener("click", handleResponse); startButton.removeEventListener("click", onStart);
        pauseButton.removeEventListener("click", onPause); exitButton.removeEventListener("click", onExit);
        document.removeEventListener("keydown", onKey); document.removeEventListener("visibilitychange", onVisibility);
    }

    target.addEventListener("click", handleResponse); startButton.addEventListener("click", onStart);
    pauseButton.addEventListener("click", onPause); exitButton.addEventListener("click", onExit);
    document.addEventListener("keydown", onKey); document.addEventListener("visibilitychange", onVisibility);
    setCleanup(dispose);
}
